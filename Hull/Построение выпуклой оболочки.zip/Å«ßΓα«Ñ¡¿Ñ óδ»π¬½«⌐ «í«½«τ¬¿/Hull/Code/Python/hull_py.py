from tkinter import *

class Point:
    def __init__(self,x,y):
        self.x=x
        self.y=y
    def __lt__(self,other):
        return bool((self.x<other.x)|((self.x==other.x)&(self.y<other.y)))
    def __str__(self):
        return str(self.x)+' '+str(self.y)

    
root = Tk()
root.title="Построение выпуклой оболочки"
c=[]
h=[]
a=0
b=0
canv = Canvas(root, width = 1500, height = 800, bg = "white")
name_file_all="output.txt"
file_all=open(name_file_all)
name_file_hull="out_hull.txt"
file_hull=open(name_file_hull)
i=0

for line in file_all:
    if i%2==0:
        a=int(line)
    else:
        b=int(line)
        buf=Point(a,b)
        c.append(buf)
    i+=1
file_all.close()
for a in c:
    canv.create_oval(a.x-3, a.y-3, a.x+3, a.y+3, outline="red", fill="red", width=0)
i=0
for line in file_hull:
    if i%2==0:
        a=int(line)
    else:
        b=int(line)
        buf=Point(a,b)
        h.append(buf)
    i+=1
file_hull.close()
for i in range(1,len(h)):
    canv.create_oval(h[i].x-3, h[i].y-3, h[i].x+3, h[i].y+3, outline="blue", fill="blue", width=0)
    canv.create_line(h[i-1].x,h[i-1].y,h[i].x,h[i].y,width=2,arrow=LAST)
canv.create_line(h[len(h)-1].x,h[len(h)-1].y,h[0].x,h[0].y,width=2,arrow=LAST)
canv.create_oval(h[0].x-3, h[0].y-3, h[0].x+3, h[0].y+3, outline="blue", fill="blue", width=0)
canv.pack()	
root.mainloop()
        
