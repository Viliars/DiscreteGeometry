#include <iostream>
#include <fstream>
#include <ctime>
using namespace std;

int main()
{
    srand(time(NULL));
    int a,b;
    ofstream out("input.txt", ios_base::out | ios_base::trunc );
    for(int i=0;i<99;++i)
    {
        a=10+rand()%1480;
        b=10+rand()%780;
        out<<a<<" "<<b<<endl;
    }
    a=10+rand()%1480;
    b=10+rand()%780;
     out<<a<<" "<<b;
    return 0;
}
