#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
namespace hull{
    typedef int uint;
    const uint FF=256;
    const uint FE=255;
    const uint eight=8;

    class Point {
        public:
            uint x,y;
            Point(uint x=0,uint y=0) { this->x=x; this->y=x; }
             friend std::istream& operator >> ( std::istream& os, Point& obj);
             friend std::ostream& operator << ( std::ostream& os, Point& obj);
    };

    std::istream& operator >> ( std::istream& os, Point& obj)
    {
    os>>obj.x>>obj.y;
    return os;
    }

    std::ostream& operator << ( std::ostream& os, Point& obj)
    {
    os<<obj.x<<std::endl<<obj.y;
    return os;
    }

    bool ClockWise (const Point& a,const Point& b,const Point& c)
    {
	return a.x*(b.y-c.y)+b.x*(c.y-a.y)+c.x*(a.y-b.y) < 0;
    }

    bool CounterClockWise (const Point& a,const Point& b,const Point& c)
    {
        return a.x*(b.y-c.y)+b.x*(c.y-a.y)+c.x*(a.y-b.y) > 0;
    }

    void convex_hull (std::vector<Point> & a)
    {
        int n=a.size();
        std::vector<uint> mid(n);
        for(int i=0;i<n;++i)
        {
            mid[i]=a[i].x*10000+a[i].y;
        }
        std::vector<int> buf(FF);
        std::vector<int> point(FF);
        std::vector<uint> bufer(n);
        if (a.size() == 1)  return;

        for (int i = 0; i < 32; i+=eight)
        {
            point[0] = 0;
            for (int k = 0; k < FF; ++k) buf[k] = 0;
            for (int k = 0; k < n; ++k) ++buf[mid[k] >> i & FE];
            for (int k = 1; k < FF; ++k) point[k] = point[k - 1] + buf[k - 1];
            for (int k = 0; k < n; ++k) bufer[point[mid[k] >> i & FE]++] = mid[k];
            mid.swap(bufer);
        }
        for(size_t i=0;i<mid.size();++i)
        {
            a[i].x=mid[i]/10000;
            a[i].y=mid[i]%10000;
        }
        reverse(a.begin(),a.end());
        Point p1 = a[0],  p2 = a.back();
        std::vector<Point> up, down;
        up.push_back (p1);
        down.push_back (p1);
        for (size_t i=1; i<a.size(); ++i)
        {
            if (i==a.size()-1 || ClockWise(p1, a[i], p2))
            {
                while (up.size()>=2 && !ClockWise(up[up.size()-2], up[up.size()-1], a[i])) up.pop_back();
                up.push_back (a[i]);
            }
            if (i==a.size()-1 || CounterClockWise(p1, a[i], p2))
            {
                while (down.size()>=2 && !CounterClockWise(down[down.size()-2], down[down.size()-1], a[i])) down.pop_back();
                down.push_back (a[i]);
            }
        }
        a.clear();
        for (size_t i=0; i<up.size(); ++i) a.push_back (up[i]);
        for (size_t i=down.size()-2; i>0; --i) a.push_back (down[i]);
    }

}

using namespace std;
using namespace hull;

int main()
{
    ifstream in("input.txt", ios_base::in);
    ofstream out("output.txt", ios_base::out | ios_base::trunc );
    ofstream out2("out_hull.txt", ios_base::out | ios_base::trunc );
    vector<Point> a;
    Point c;
    while(in>>c)
    {
        a.push_back(c);
    }
    for(size_t i=0;i<a.size()-1;++i)
    {
        out<<a[i]<<endl;
    }
    out<<a[a.size()-1];

    convex_hull(a);
    for(size_t i=0;i<a.size()-1;++i)
    {
        out2<<a[i]<<endl;
    }
    out2<<a[a.size()-1];
    out.close();
    out2.close();
    system("hull_py.exe");
    system("random.exe");
    return 0;
}
