from tkinter import *
import subprocess
class Point:
    def __init__(self,x,y):
        self.x=x
        self.y=y
    def __lt__(self,other):
        return bool((self.x<other.x)|((self.x==other.x)&(self.y<other.y)))
    def __str__(self):
        return str(self.x)+' '+str(self.y)
    
class Example(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)   
         
        self.parent = parent        
        self.initUI()
        
    def initUI(self):
        self.parent.title("Scale")
        #self.style = Style()
        #self.style.theme_use("default")        
        
        self.pack(fill=BOTH, expand=1)

        scale = Scale(self, from_=1, to=20, orient=HORIZONTAL,
            command=self.onScale)
        scale.pack(side=LEFT, padx=15)

        self.var = IntVar()
        self.label = Label(self, text=0, textvariable=self.var)        
        self.label.pack(side=LEFT)
        self.var.set(10)
        scale.set(10)
    def onScale(self, val):
        global core
        v = int(float(val))
        self.var.set(v)
        core=v
        run()
#---------------------------------
class Example2(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)   
         
        self.parent = parent        
        self.initUI()
        
    def initUI(self):
        self.parent.title("Scale")
        #self.style = Style()
        #self.style.theme_use("default")        
        
        self.pack(fill=BOTH, expand=1)

        scale = Scale(self, from_=100, to=300, orient=HORIZONTAL, sliderlength=10,
            command=self.onScale)
        scale.pack(side=LEFT,padx=15)

        self.var = IntVar()
        self.label = Label(self, text=0, textvariable=self.var)        
        self.label.pack(side=LEFT)
        self.var.set(100)
        scale.set(100)
    def onScale(self, val):
        global dx
        v = int(float(val))
        self.var.set(v)
        dx=v
        run()
#-----------------------------------
class Example3(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)   
         
        self.parent = parent        
        self.initUI()
        
    def initUI(self):
        self.parent.title("Scale")
        #self.style = Style()
        #self.style.theme_use("default")        
        
        self.pack(fill=BOTH, expand=1)

        scale = Scale(self, from_=20, to=300, orient=HORIZONTAL, sliderlength=10,
            command=self.onScale)
        scale.pack(side=LEFT,padx=15)

        self.var = IntVar()
        self.label = Label(self, text=0, textvariable=self.var)        
        self.label.pack(side=LEFT)
        scale.set(50)
    def onScale(self, val):
        global s
        global beze
        global fel
        v = int(float(val))
        self.var.set(v)
        s=str(v)
        subprocess.check_call([r'Beze.exe', s, beze, fel])
        run()
        
class Example4(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)   
         
        self.parent = parent        
        self.initUI()
        
    def initUI(self):
        self.parent.title("Scale")
        #self.style = Style()
        #self.style.theme_use("default")        
        
        self.pack(fill=BOTH, expand=1)

        scale = Scale(self, from_=10, to=500, orient=HORIZONTAL, sliderlength=10,
            command=self.onScale)
        scale.pack(side=LEFT,padx=15)

        self.var = IntVar()
        self.label = Label(self, text=0, textvariable=self.var)        
        self.label.pack(side=LEFT)
        self.var.set(200)
        scale.set(200)
    def onScale(self, val):
        global s
        global beze
        global fel
        v = int(float(val))
        self.var.set(v)
        beze=str(v)
        subprocess.check_call([r'Beze.exe', s, beze, fel])
        run()
class Example5(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)   
         
        self.parent = parent        
        self.initUI()
        
    def initUI(self):
        self.parent.title("Scale")
        #self.style = Style()
        #self.style.theme_use("default")        
        
        self.pack(fill=BOTH, expand=1)

        scale = Scale(self, from_=10, to=500, orient=HORIZONTAL, sliderlength=10,
            command=self.onScale)
        scale.pack(side=LEFT,padx=15)

        self.var = IntVar()
        self.label = Label(self, text=0, textvariable=self.var)        
        self.label.pack(side=LEFT)
        self.var.set(300)
        scale.set(300)
    def onScale(self, val):
        global s
        global beze
        global fel
        v = int(float(val))
        self.var.set(v)
        fel=str(v)
        subprocess.check_call([r'Beze.exe', s, beze, fel])
        run()
def SetDef():
    global ex1
    global ex2
    global ex3
    global ex4
    global ex5
    ex1.onScale(10)
    ex2.onScale(100)
    ex3.onScale(50)
    ex4.onScale(200)
    ex5.onScale(300)
    run()
core=1
dx=100
beze=str(200)
s=str(50)
fel=str(300)
root = Tk()
canv = Canvas(root, width = 1500, height = 800, bg = "white")
ex1= Example(root)
ex2= Example2(root)
ex3= Example3(root)
ex4= Example4(root)
ex5= Example5(root)
B = Button(root,text ="Default", command = SetDef)
B.pack()

def run():
    global canv
    global core
    global dx
    canv.delete("all")
    i=0
    c=[]
    h=[]
    a=0
    b=0
    name_file_all="output.txt"
    file_all=open(name_file_all)
    name_file_hull="input.txt"
    file_hull=open(name_file_hull)
    for line in file_all:
        if i%2==0:
            a=dx+core*float(line)
        else:
            b=dx+core*float(line)
            buf=Point(a,b)
            c.append(buf)
        i+=1
    file_all.close()
    for a in c:
        canv.create_oval(a.x-1, a.y-1, a.x+1, a.y+1, outline="red", fill="red", width=0)
    i=0
    for line in file_hull:
        if i%2==0:
            a=dx+core*float(line)
        else:
            b=dx+core*float(line)
            buf=Point(a,b)
            h.append(buf)
        i+=1
    file_hull.close()
    for i in range(1,len(h)):
        canv.create_oval(h[i].x-3, h[i].y-3, h[i].x+3, h[i].y+3, outline="blue", fill="blue", width=0)
    canv.create_oval(h[0].x-3, h[0].y-3, h[0].x+3, h[0].y+3, outline="blue", fill="blue", width=0)
    canv.pack()
run()
root.mainloop()
